export default function ActividadesPage() {
    return (
    <div className="space-y-4">
 Resumen general del sistema.

    </div>
  );
}
